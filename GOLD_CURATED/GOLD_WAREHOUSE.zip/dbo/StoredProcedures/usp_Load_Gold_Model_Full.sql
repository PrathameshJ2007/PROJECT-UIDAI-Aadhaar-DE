CREATE   PROCEDURE [dbo].[usp_Load_Gold_Model_Full]
AS
BEGIN

    SET NOCOUNT ON;

    -- =========================================================================
    -- 1. DROP EXISTING GOLD TABLES
    -- =========================================================================

    DROP TABLE IF EXISTS [GOLD_WAREHOUSE].[dbo].[Fact_Aadhaar_Activity];
    DROP TABLE IF EXISTS [GOLD_WAREHOUSE].[dbo].[Dim_Location];
    DROP TABLE IF EXISTS [GOLD_WAREHOUSE].[dbo].[Dim_Date];

    DROP TABLE IF EXISTS [GOLD_WAREHOUSE].[dbo].[Enrolment];
    DROP TABLE IF EXISTS [GOLD_WAREHOUSE].[dbo].[Demographic];
    DROP TABLE IF EXISTS [GOLD_WAREHOUSE].[dbo].[Biometric];


    -- =========================================================================
    -- 2. CREATE GOLD SOURCE TABLES
    -- =========================================================================

    SELECT
        TRY_CONVERT(DATE, [date]) AS [date],
        [pincode],
        [state],
        [district],
        [age_0_5],
        [age_5_17],
        [age_18_greater]
    INTO [GOLD_WAREHOUSE].[dbo].[Enrolment]
    FROM [SILVER_Enriched_LAKEHOUSE].[dbo].[enrolment];


    SELECT
        TRY_CONVERT(DATE, [date]) AS [date],
        [pincode],
        [state],
        [district],
        [demo_age_5_17],
        [demo_age_17_]
    INTO [GOLD_WAREHOUSE].[dbo].[Demographic]
    FROM [SILVER_Enriched_LAKEHOUSE].[dbo].[demographic];


    SELECT
        TRY_CONVERT(DATE, [date]) AS [date],
        [pincode],
        [state],
        [district],
        [bio_age_17_],
        [bio_age_5_17]
    INTO [GOLD_WAREHOUSE].[dbo].[Biometric]
    FROM [SILVER_Enriched_LAKEHOUSE].[dbo].[biometric];


    -- =========================================================================
    -- 3. CREATE DIM_LOCATION
    -- =========================================================================

    CREATE TABLE [GOLD_WAREHOUSE].[dbo].[Dim_Location]
    (
        [LocationKey] BIGINT IDENTITY NOT NULL,
        [Pincode]     VARCHAR(50),
        [District]    VARCHAR(100),
        [State]       VARCHAR(100)
    );


    INSERT INTO [GOLD_WAREHOUSE].[dbo].[Dim_Location]
    (
        [Pincode],
        [District],
        [State]
    )
    SELECT DISTINCT
        [pincode],
        [district],
        [state]
    FROM
    (
        SELECT
            [pincode],
            [district],
            [state]
        FROM [GOLD_WAREHOUSE].[dbo].[Enrolment]

        UNION

        SELECT
            [pincode],
            [district],
            [state]
        FROM [GOLD_WAREHOUSE].[dbo].[Demographic]

        UNION

        SELECT
            [pincode],
            [district],
            [state]
        FROM [GOLD_WAREHOUSE].[dbo].[Biometric]
    ) AS src
    WHERE [pincode] IS NOT NULL;


    -- =========================================================================
    -- 4. CREATE DIM_DATE
    -- =========================================================================

    CREATE TABLE [GOLD_WAREHOUSE].[dbo].[Dim_Date]
    (
        [DateKey]    INT NOT NULL,
        [Date]       DATE NOT NULL,
        [Year]       INT,
        [Quarter]    INT,
        [Month]      INT,
        [MonthName]  VARCHAR(20),
        [DayOfWeek]  INT
    );


    INSERT INTO [GOLD_WAREHOUSE].[dbo].[Dim_Date]
    (
        [DateKey],
        [Date],
        [Year],
        [Quarter],
        [Month],
        [MonthName],
        [DayOfWeek]
    )
    SELECT DISTINCT

        CONVERT(
            INT,
            CONVERT(
                CHAR(8),
                [date],
                112
            )
        ) AS [DateKey],

        [date] AS [Date],

        YEAR([date]) AS [Year],

        DATEPART(
            QUARTER,
            [date]
        ) AS [Quarter],

        MONTH([date]) AS [Month],

        DATENAME(
            MONTH,
            [date]
        ) AS [MonthName],

        DATEPART(
            WEEKDAY,
            [date]
        ) AS [DayOfWeek]

    FROM
    (
        SELECT TRY_CONVERT(DATE, [date]) AS [date]
        FROM [SILVER_Enriched_LAKEHOUSE].[dbo].[enrolment]

        UNION

        SELECT TRY_CONVERT(DATE, [date]) AS [date]
        FROM [SILVER_Enriched_LAKEHOUSE].[dbo].[demographic]

        UNION

        SELECT TRY_CONVERT(DATE, [date]) AS [date]
        FROM [SILVER_Enriched_LAKEHOUSE].[dbo].[biometric]
    ) AS src

    WHERE [date] IS NOT NULL;


    -- =========================================================================
    -- 5. CREATE FACT TABLE
    -- =========================================================================

    CREATE TABLE [GOLD_WAREHOUSE].[dbo].[Fact_Aadhaar_Activity]
    (
        [DateKey]              INT,
        [LocationKey]          BIGINT,

        [enrol_age_0_5]        INT,
        [enrol_age_5_17]       INT,
        [enrol_age_18_greater] INT,

        [demo_age_5_17]        INT,
        [demo_age_17_]         INT,

        [bio_age_5_17]         INT,
        [bio_age_17_]          INT
    );


    -- =========================================================================
    -- 6. AGGREGATE SILVER/GOLD SOURCE TABLES
    -- =========================================================================
    --
    -- IMPORTANT:
    -- Each source is first aggregated to:
    --
    -- Date + Pincode + District + State
    --
    -- This prevents many-to-many joins from multiplying fact rows.
    -- =========================================================================

    ;WITH EnrolmentAgg AS
    (
        SELECT
            [date],
            [pincode],
            [district],
            [state],

            SUM(ISNULL([age_0_5], 0)) AS [enrol_age_0_5],

            SUM(ISNULL([age_5_17], 0)) AS [enrol_age_5_17],

            SUM(ISNULL([age_18_greater], 0)) AS [enrol_age_18_greater]

        FROM [GOLD_WAREHOUSE].[dbo].[Enrolment]

        WHERE [date] IS NOT NULL

        GROUP BY
            [date],
            [pincode],
            [district],
            [state]
    ),

    DemographicAgg AS
    (
        SELECT
            [date],
            [pincode],
            [district],
            [state],

            SUM(ISNULL([demo_age_5_17], 0)) AS [demo_age_5_17],

            SUM(ISNULL([demo_age_17_], 0)) AS [demo_age_17_]

        FROM [GOLD_WAREHOUSE].[dbo].[Demographic]

        WHERE [date] IS NOT NULL

        GROUP BY
            [date],
            [pincode],
            [district],
            [state]
    ),

    BiometricAgg AS
    (
        SELECT
            [date],
            [pincode],
            [district],
            [state],

            SUM(ISNULL([bio_age_5_17], 0)) AS [bio_age_5_17],

            SUM(ISNULL([bio_age_17_], 0)) AS [bio_age_17_]

        FROM [GOLD_WAREHOUSE].[dbo].[Biometric]

        WHERE [date] IS NOT NULL

        GROUP BY
            [date],
            [pincode],
            [district],
            [state]
    ),

    ConsolidatedData AS
    (
        SELECT

            COALESCE(
                e.[date],
                d.[date],
                b.[date]
            ) AS [date],

            COALESCE(
                e.[pincode],
                d.[pincode],
                b.[pincode]
            ) AS [pincode],

            COALESCE(
                e.[district],
                d.[district],
                b.[district]
            ) AS [district],

            COALESCE(
                e.[state],
                d.[state],
                b.[state]
            ) AS [state],

            ISNULL(
                e.[enrol_age_0_5],
                0
            ) AS [enrol_age_0_5],

            ISNULL(
                e.[enrol_age_5_17],
                0
            ) AS [enrol_age_5_17],

            ISNULL(
                e.[enrol_age_18_greater],
                0
            ) AS [enrol_age_18_greater],

            ISNULL(
                d.[demo_age_5_17],
                0
            ) AS [demo_age_5_17],

            ISNULL(
                d.[demo_age_17_],
                0
            ) AS [demo_age_17_],

            ISNULL(
                b.[bio_age_5_17],
                0
            ) AS [bio_age_5_17],

            ISNULL(
                b.[bio_age_17_],
                0
            ) AS [bio_age_17_]

        FROM EnrolmentAgg e

        FULL OUTER JOIN DemographicAgg d
            ON e.[date] = d.[date]
            AND e.[pincode] = d.[pincode]
            AND ISNULL(e.[district], '') = ISNULL(d.[district], '')
            AND ISNULL(e.[state], '') = ISNULL(d.[state], '')

        FULL OUTER JOIN BiometricAgg b
            ON COALESCE(
                e.[date],
                d.[date]
            ) = b.[date]

            AND COALESCE(
                e.[pincode],
                d.[pincode]
            ) = b.[pincode]

            AND ISNULL(
                COALESCE(
                    e.[district],
                    d.[district]
                ),
                ''
            ) = ISNULL(
                b.[district],
                ''
            )

            AND ISNULL(
                COALESCE(
                    e.[state],
                    d.[state]
                ),
                ''
            ) = ISNULL(
                b.[state],
                ''
            )
    )


    -- =========================================================================
    -- 7. LOAD FACT TABLE
    -- =========================================================================

    INSERT INTO [GOLD_WAREHOUSE].[dbo].[Fact_Aadhaar_Activity]
    (
        [DateKey],
        [LocationKey],

        [enrol_age_0_5],
        [enrol_age_5_17],
        [enrol_age_18_greater],

        [demo_age_5_17],
        [demo_age_17_],

        [bio_age_5_17],
        [bio_age_17_]
    )

    SELECT

        CONVERT(
            INT,
            CONVERT(
                CHAR(8),
                c.[date],
                112
            )
        ) AS [DateKey],

        loc.[LocationKey],

        c.[enrol_age_0_5],

        c.[enrol_age_5_17],

        c.[enrol_age_18_greater],

        c.[demo_age_5_17],

        c.[demo_age_17_],

        c.[bio_age_5_17],

        c.[bio_age_17_]

    FROM ConsolidatedData c

    LEFT JOIN [GOLD_WAREHOUSE].[dbo].[Dim_Location] loc

        ON ISNULL(c.[pincode], '') =
           ISNULL(loc.[Pincode], '')

        AND ISNULL(c.[district], '') =
            ISNULL(loc.[District], '')

        AND ISNULL(c.[state], '') =
            ISNULL(loc.[State], '');

    PRINT 'Gold model loaded successfully.';

END;

GO