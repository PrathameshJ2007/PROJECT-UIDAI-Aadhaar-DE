CREATE TABLE [dbo].[Biometric] (
    [date]         DATE           NULL,
    [pincode]      INT            NULL,
    [state]        VARCHAR (8000) NULL,
    [district]     VARCHAR (8000) NULL,
    [bio_age_17_]  INT            NULL,
    [bio_age_5_17] INT            NULL
);


GO