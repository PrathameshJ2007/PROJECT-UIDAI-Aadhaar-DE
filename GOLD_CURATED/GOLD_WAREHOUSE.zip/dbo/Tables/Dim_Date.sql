CREATE TABLE [dbo].[Dim_Date] (
    [DateKey]   INT          NOT NULL,
    [Date]      DATE         NOT NULL,
    [Year]      INT          NULL,
    [Quarter]   INT          NULL,
    [Month]     INT          NULL,
    [MonthName] VARCHAR (20) NULL,
    [DayOfWeek] INT          NULL
);


GO