CREATE TABLE [dbo].[Enrolment] (
    [date]           DATE           NULL,
    [pincode]        INT            NULL,
    [state]          VARCHAR (8000) NULL,
    [district]       VARCHAR (8000) NULL,
    [age_0_5]        INT            NULL,
    [age_5_17]       INT            NULL,
    [age_18_greater] INT            NULL
);


GO