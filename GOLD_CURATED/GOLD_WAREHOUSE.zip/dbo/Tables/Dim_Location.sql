CREATE TABLE [dbo].[Dim_Location] (
    [LocationKey] BIGINT        IDENTITY NOT NULL,
    [Pincode]     VARCHAR (50)  NULL,
    [District]    VARCHAR (100) NULL,
    [State]       VARCHAR (100) NULL
);


GO