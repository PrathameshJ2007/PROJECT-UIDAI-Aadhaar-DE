CREATE TABLE [dbo].[Fact_Aadhaar_Activity] (
    [DateKey]              INT    NULL,
    [LocationKey]          BIGINT NULL,
    [enrol_age_0_5]        INT    NULL,
    [enrol_age_5_17]       INT    NULL,
    [enrol_age_18_greater] INT    NULL,
    [demo_age_5_17]        INT    NULL,
    [demo_age_17_]         INT    NULL,
    [bio_age_5_17]         INT    NULL,
    [bio_age_17_]          INT    NULL
);


GO