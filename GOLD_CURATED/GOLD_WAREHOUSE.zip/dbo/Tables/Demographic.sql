CREATE TABLE [dbo].[Demographic] (
    [date]          DATE           NULL,
    [pincode]       INT            NULL,
    [state]         VARCHAR (8000) NULL,
    [district]      VARCHAR (8000) NULL,
    [demo_age_5_17] INT            NULL,
    [demo_age_17_]  INT            NULL
);


GO